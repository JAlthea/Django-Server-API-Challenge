from django.contrib import admin
from myapp.item.models import Item, Ingredient

# Register your models here.
admin.site.register(Item)
admin.site.register(Ingredient)