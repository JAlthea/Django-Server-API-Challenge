import os
from .base import *

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'HOST': 'localhost',
        'NAME': 'mysite',
        'USER': 'root',
        'PASSWORD': 'sxdc5521!!',
    }
}